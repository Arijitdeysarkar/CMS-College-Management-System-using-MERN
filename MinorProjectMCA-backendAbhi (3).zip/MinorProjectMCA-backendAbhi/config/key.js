module.exports = {
    secretOrKey: 'mySecretKey'
};